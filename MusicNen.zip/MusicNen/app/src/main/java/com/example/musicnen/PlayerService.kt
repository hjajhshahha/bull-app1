package com.example.musicnen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Dịch vụ nền: chọn bài ngẫu nhiên từ .mucsic, lấy link âm thanh bằng NewPipeExtractor,
 * phát bằng ExoPlayer. Hết bài thì tự chọn bài kế tiếp.
 */
class PlayerService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.musicnen.STOP"
        const val ACTION_NEXT = "com.example.musicnen.NEXT"
        private const val CHANNEL_ID = "music_nen"
        private const val NOTIF_ID = 1
        private const val MAX_TRIES = 6
        @Volatile private var extractorReady = false
    }

    private class Resolved(val url: String, val title: String)

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val gen = AtomicInteger(0)
    @Volatile private var destroyed = false
    private var player: ExoPlayer? = null
    private var foregroundOn = false
    private var errorCount = 0
    private var currentTitle = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Music nền", NotificationManager.IMPORTANCE_LOW)
        )
        if (!extractorReady) {
            NewPipe.init(DownloaderImpl.instance)
            extractorReady = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (!foregroundOn) {
            val n = buildNotification("Đang chuẩn bị")
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIF_ID, n)
            }
            foregroundOn = true
        }
        errorCount = 0
        playNext()
        return START_NOT_STICKY
    }

    private fun shutdown() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Luôn gọi trên luồng chính. */
    private fun playNext() {
        val my = gen.incrementAndGet()
        player?.stop()
        updateNotification("Đang tìm bài")
        executor.execute {
            val failed = HashSet<String>()
            var lastError = ""
            var tries = 0
            while (tries < MAX_TRIES && !destroyed && my == gen.get()) {
                tries++
                val entry = try {
                    MusicStore.pickRandom(this, failed)
                } catch (e: Exception) {
                    lastError = "Không đọc được file .mucsic: " + (e.message ?: "")
                    break
                }
                if (entry == null) {
                    if (lastError.isEmpty()) lastError = "Không còn link hợp lệ trong .mucsic"
                    break
                }
                try {
                    val r = resolve(entry.id)
                    MusicStore.markPlayed(this, entry.id)
                    main.post {
                        if (my == gen.get() && !destroyed) startPlayback(r)
                    }
                    return@execute
                } catch (e: Exception) {
                    failed.add(entry.id)
                    lastError = e.message ?: e.javaClass.simpleName
                }
            }
            if (my == gen.get() && !destroyed) {
                main.post { fail(lastError) }
            }
        }
    }

    private fun resolve(id: String): Resolved {
        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$id")
        val streams = info.audioStreams.filter {
            it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP
        }
        val best = streams.filter { it.format == MediaFormat.M4A }.maxByOrNull { it.averageBitrate }
            ?: streams.maxByOrNull { it.averageBitrate }
            ?: throw IllegalStateException("Video không có luồng âm thanh dùng được")
        return Resolved(best.content, info.name ?: id)
    }

    private fun startPlayback(r: Resolved) {
        player?.release()
        val dataSource = DefaultHttpDataSource.Factory()
            .setUserAgent(DownloaderImpl.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSource))
            .build()
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true
        )
        p.setHandleAudioBecomingNoisy(true)
        p.setWakeMode(C.WAKE_MODE_NETWORK)
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    errorCount = 0
                } else if (playbackState == Player.STATE_ENDED) {
                    playNext()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                errorCount++
                if (errorCount > MAX_TRIES) {
                    fail(error.message ?: "Lỗi phát nhạc")
                } else {
                    playNext()
                }
            }
        })
        p.setMediaItem(MediaItem.fromUri(r.url))
        p.prepare()
        p.playWhenReady = true
        player = p
        currentTitle = r.title
        updateNotification(r.title)
    }

    private fun fail(message: String) {
        player?.release()
        player = null
        updateNotification("Lỗi: $message")
        main.postDelayed({ if (!destroyed) shutdown() }, 20000)
    }

    private fun buildNotification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(
            this, 1, Intent(this, PlayerService::class.java).setAction(ACTION_STOP), flags
        )
        val next = PendingIntent.getService(
            this, 2, Intent(this, PlayerService::class.java).setAction(ACTION_NEXT), flags
        )
        @Suppress("DEPRECATION")
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Music nền")
            .setContentText(text)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_next, "Bài khác", next)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Tắt", stop)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        destroyed = true
        gen.incrementAndGet()
        player?.release()
        player = null
        executor.shutdownNow()
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
