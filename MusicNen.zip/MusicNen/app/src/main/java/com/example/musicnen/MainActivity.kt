package com.example.musicnen

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings

/**
 * Activity trong suốt: xin quyền (chỉ hỏi một lần cho mỗi quyền), tạo file .mucsic,
 * bật PlayerService rồi tự đóng ngay.
 * Bấm lại icon khi nhạc đang phát thì service sẽ chuyển sang một bài ngẫu nhiên khác.
 */
class MainActivity : Activity() {

    private var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        proceed()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        proceed()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        proceed()
    }

    private fun proceed() {
        if (started || isFinishing) return
        val asked = getSharedPreferences("perm_asked", Context.MODE_PRIVATE)

        // 1. Quyền thông báo (Android 13 trở lên)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !asked.getBoolean("notif", false)
        ) {
            asked.edit().putBoolean("notif", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
            return
        }

        // 2. Quyền ghi file ở thư mục gốc của máy
        if (!MusicStore.hasStorageAccess(this) && !asked.getBoolean("storage", false)) {
            asked.edit().putBoolean("storage", true).apply()
            if (Build.VERSION.SDK_INT >= 30) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(intent, 200)
                } catch (e: Exception) {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), 200)
                }
            } else {
                requestPermissions(
                    arrayOf(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                    101
                )
            }
            return
        }

        // 3. Cho phép chạy nền không bị tối ưu pin
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !asked.getBoolean("battery", false)) {
            asked.edit().putBoolean("battery", true).apply()
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    ),
                    201
                )
                return
            } catch (e: Exception) {
                // thiết bị không hỗ trợ màn hình này, bỏ qua
            }
        }

        started = true
        try {
            MusicStore.ensureFile(this)
        } catch (e: Exception) {
            // không ghi được file thì service vẫn báo lỗi rõ ràng sau
        }
        val svc = Intent(this, PlayerService::class.java)
        try {
            startForegroundService(svc)
        } catch (e: Exception) {
            startService(svc)
        }
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}
