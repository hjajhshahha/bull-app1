package com.example.musicnen

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import java.io.File

data class Entry(val id: String, val raw: String)

/**
 * Quản lý file danh sách bài (.mucsic) và trạng thái đã phát.
 * Mỗi dòng trong file là một link YouTube. Dòng trống và dòng bắt đầu bằng # bị bỏ qua.
 * Trạng thái "đã phát" lưu trong SharedPreferences theo ID video, nên sửa file thoải mái.
 */
object MusicStore {
    const val FILE_NAME = ".mucsic"
    const val DEFAULT_LINK =
        "https://m.youtube.com/watch?v=GJ07_Nk4sBs&list=PLNk91vqLmfns&index=1&pp=sAgC"

    private val ID_REGEX = Regex("""(?:[?&]v=|youtu\.be/|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})""")

    fun hasStorageAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    /** Có quyền thì dùng thư mục gốc của máy, không thì dùng thư mục riêng của app. */
    fun musicFile(ctx: Context): File =
        if (hasStorageAccess(ctx)) {
            File(Environment.getExternalStorageDirectory(), FILE_NAME)
        } else {
            File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, FILE_NAME)
        }

    /** Chỉ tạo khi chưa có, không ghi đè danh sách bạn đã sửa. */
    fun ensureFile(ctx: Context): File {
        val f = musicFile(ctx)
        if (!f.exists()) {
            f.parentFile?.mkdirs()
            f.writeText(DEFAULT_LINK + "\n")
        }
        return f
    }

    fun videoId(line: String): String? = ID_REGEX.find(line)?.groupValues?.get(1)

    fun load(ctx: Context): List<Entry> {
        val f = ensureFile(ctx)
        val result = LinkedHashMap<String, Entry>()
        for (raw in f.readLines()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val id = videoId(line) ?: continue
            if (!result.containsKey(id)) result[id] = Entry(id, line)
        }
        return result.values.toList()
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("music_state", Context.MODE_PRIVATE)

    private fun playedSet(ctx: Context): HashSet<String> =
        HashSet<String>(prefs(ctx).getStringSet("played", null) ?: emptySet<String>())

    /**
     * Chọn ngẫu nhiên một bài chưa phát. Khi tất cả đã được đánh dấu thì bỏ đánh dấu
     * và bắt đầu vòng mới. exclude là các bài vừa lỗi trong lượt này.
     */
    fun pickRandom(ctx: Context, exclude: Set<String>): Entry? {
        val all = load(ctx)
        if (all.isEmpty()) return null
        val allIds = all.map { it.id }.toSet()

        var played = playedSet(ctx)
        played.retainAll(allIds)
        var unplayed = all.filter { it.id !in played }
        if (unplayed.isEmpty()) {
            played = HashSet()
            prefs(ctx).edit().putStringSet("played", played).apply()
            unplayed = all
        }

        var pool = unplayed.filter { it.id !in exclude }
        val last = prefs(ctx).getString("last", null)
        if (pool.size > 1 && last != null) {
            val others = pool.filter { it.id != last }
            if (others.isNotEmpty()) pool = others
        }
        return pool.randomOrNull()
    }

    fun markPlayed(ctx: Context, id: String) {
        val played = playedSet(ctx)
        played.add(id)
        prefs(ctx).edit().putStringSet("played", played).putString("last", id).apply()
    }
}
