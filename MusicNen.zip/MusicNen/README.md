# Music nền

App Android (Kotlin) phát nhạc YouTube dưới dạng âm thanh nền.

## Cách hoạt động

1. Mở app lần đầu: app xin quyền (thông báo, truy cập tệp, bỏ tối ưu pin), mỗi quyền chỉ hỏi một lần.
2. App tạo tệp `.mucsic` ở thư mục gốc của máy (`/storage/emulated/0/.mucsic`), chỉ tạo khi chưa có, trong đó có sẵn một link. Nếu bạn không cấp quyền truy cập tệp, app dùng thư mục riêng `Android/data/com.example.musicnen/files/`.
3. Mỗi dòng trong `.mucsic` là một link YouTube. Dòng trống và dòng bắt đầu bằng `#` bị bỏ qua. Sửa file thoải mái, app đọc lại mỗi lần chọn bài.
4. App chọn ngẫu nhiên một bài chưa phát, đánh dấu đã phát (lưu theo ID video), lấy luồng âm thanh và phát nền. Hết bài thì chọn bài ngẫu nhiên kế tiếp.
5. Khi mọi bài đều đã đánh dấu, app bỏ hết đánh dấu và bắt đầu vòng mới (không phát lại đúng bài vừa xong ở đầu vòng mới).
6. Giao diện tự đóng ngay sau khi bật dịch vụ nền. Nhạc vẫn chạy, thông báo có nút "Bài khác" và "Tắt".
7. Bấm lại icon app khi đang phát sẽ chuyển sang một bài ngẫu nhiên khác. Dùng được từ nút widget KWGT hoặc MacroDroid.

Đổi tên tệp ở hằng `FILE_NAME` trong `MusicStore.kt` nếu muốn.

## Build ra APK bằng GitHub Actions (không cần cài Android Studio)

1. Tạo repo mới trên GitHub, đưa toàn bộ thư mục này lên (giữ nguyên cấu trúc, gồm cả thư mục `.github`).
   - Trên máy tính: vào repo, bấm Add file, Upload files, kéo thả cả thư mục.
   - Trên điện thoại: dùng Termux, cài `git`, rồi `git init`, `git add .`, `git commit`, `git push`.
2. Vào tab Actions, chọn workflow "Build APK", bấm Run workflow (hoặc workflow tự chạy khi push).
3. Chờ xong, mở lần chạy đó, tải mục Artifacts tên `music-nen-apk`, giải nén lấy `app-debug.apk`. File này đã tự ký bằng khóa debug nên cài được ngay.

## Build bằng Android Studio

Mở thư mục này, để Android Studio đồng bộ Gradle, rồi chọn Build, Build APK. Cần JDK 17.

## Nếu có lỗi

- **Gradle không tìm thấy NewPipeExtractor:** đổi chuỗi `v0.24.6` trong `app/build.gradle.kts` sang tag mới nhất ở trang Releases của TeamNewPipe/NewPipeExtractor. Nếu vẫn lỗi, thử tọa độ `com.github.TeamNewPipe.NewPipeExtractor:extractor:<tag>`.
- **Báo lỗi khi lấy video (403, cần đăng nhập, không có luồng âm thanh):** YouTube hay đổi cách phát, phiên bản thư viện cũ sẽ hỏng. Cập nhật tag như trên rồi build lại.
- **Nhạc bị dừng sau một lúc:** vào cài đặt pin của máy, đặt app ở chế độ không hạn chế.
- **Link có `list=` bị cắt ngắn:** app chỉ dùng phần `v=` của link, không phát cả danh sách phát.
